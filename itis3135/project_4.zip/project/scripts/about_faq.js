$(document).ready(function() {

    // BX slider to rotate the pictures for the smock pattern
    $("#accordion").accordion({
        event: "click",
        heightStyle: "content",
        collapsible: true,
        active: false
    })

});
