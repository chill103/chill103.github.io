$(document).ready(function() {

    // BX slider to rotate the pictures for the smock pattern
    $("#slider").bxSlider({
        auto: true,
        minSlides: 1, 
        maxSlides: 1,
        slideWidth: 600,
        speed: 600,
        slideMargin:10
    })

});
